import rclpy
from rclpy.node import Node
from std_msgs.msg import String


class Talker(Node):
            def __init__(self):
                super().__init__('talker')
                self.publisher_1 = self.create_publisher(String, 'topic1', 10)
                self.timer = self.create_timer(1, self.timer_callback)
                self.msg = String()
                self.msg.data = 'Hello'


            def timer_callback(self):
                self.publisher_1.publish(self.msg)
                #self.publisher_2.publish(self.msg)
                self.get_logger().info('publishing: "%s"' % self.msg.data)

def main(args=None):
        rclpy.init(args=args)
        talker = Talker()
        rclpy.spin(talker)
        rclpy.shutdown()

if __name__ == '_main__':
        main()