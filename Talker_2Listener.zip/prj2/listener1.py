import rclpy
from rclpy.node import Node
from std_msgs.msg import String

class Listener1(Node):
    def __init__ (self):
        super().__init__('listener1')
        self.publisher = self.create_publisher(String, 'topic2', 10)
        self._subscriptions == self.create_subscription (
            String,
            'topic1',
            self.listener_callback,
            10)
        
        self.subscriptions
    
    def listener_callback(self, msg):
        self.get_logger().info('I received:"%s"' % msg.data)
        
        msg.data = msg.data.replace("Hello","Hi")

        self.publisher.publish(msg)


def main(args=None):
    rclpy.init(args=args)
    listener = Listener1()
    rclpy.spin(listener)
    rclpy.shutdown()


if __name__ == '__main__':

    main()  